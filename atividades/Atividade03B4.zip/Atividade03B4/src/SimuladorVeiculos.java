public class SimuladorVeiculos {
	
	// Interface
	interface Veiculo {
		void mover();
	}
	
	public static void main(String[] args) {
		// Classe anônima de carro
		Veiculo carro = new Veiculo() {
			@Override
			public void mover() {
				System.out.println("\tO carro está se movendo rapidamente na estrada.");
			}
		};
		
		// Classe anônima para bicicleta
		Veiculo bicicleta = new Veiculo() {
			@Override
			public void mover() {
				System.out.println("\tA bicicleta está sendo pedalada no parque.");
			}
		};
		
		// Classe anônima para caminhão
		Veiculo caminhao = new Veiculo() {
			@Override
			public void mover() {
				System.out.println("\tO caminhão está transportando carga pesada.");
			}
		};
		
		// Chamando método 'mover' para cada veículo
		System.out.println("Ações dos veículos:");
		carro.mover();
		bicicleta.mover();
		caminhao.mover();
		
		// Adicionando mais veículos com classes anônimas
		// Classe anônima para moto
		Veiculo moto = new Veiculo() {
			@Override
			public void mover() {
                System.out.println("\tA moto está acelerando pela rua.");
			}
		};
		
		// Classe anônima para quadriciclo
		Veiculo quadriciclo = new Veiculo() {
			@Override
			public void mover() {
				System.out.println("\tO quadriciclo está correndo pela trilha.");
			}
		};
		
		// Classe anônima para trem
		Veiculo trem = new Veiculo() {
			@Override
			public void mover() {
				System.out.println("\tO trem está saindo da estação.");
			}
		};
		
		// Chamando método 'mover' para os novos veículos
		System.out.println("\nAções dos novos veículos:");
		moto.mover();
		quadriciclo.mover();
		trem.mover();
	}
}