public class Banco {
	
	// Classe estática
	public static class Conta {
		private int id;
		private String titular;
		private double saldo;
		
		// Construtor
		public Conta(int id, String titular, double saldo) {
			this.id = id;
			this.titular = titular;
			this.saldo = saldo;
		}
		
		// Método de depósito
		public void depositar(double valor) {
			if (valor > 0) {
				saldo += valor;
				System.out.println("Depósito de R$ " + valor + " realizado com sucesso para a conta ID: " + id);
			} else {
				System.out.println("Valor de depósito inválido para a conta ID: " + id);
			}
			
		}
		
		// Método de sacar
		public void sacar(double valor) {
			if (valor > 0 && saldo >= valor) {
				saldo -= valor;
				System.out.println("Saque de R$ " + valor + " realizado com sucesso para a conta ID: " + id);
			} else if (valor > saldo) {
				System.out.println("Saldo insuficiente para saque");
			} else { 
				System.out.println("Valor de saque inválido");
			}
		}
		
		// Método para exibir
		public void exibirDetahles() {
			System.out.println("\t-----------------------------");
			System.out.println("\tConta ID: " + id);
			System.out.println("\tTitular: " + titular);
			System.out.printf("\tSaldo: R$ %.2f%n", saldo);
			System.out.println("\t-----------------------------");
		}
	}
	
	// Método main
	public static void main(String[] args) {
		Conta conta_1 = new Conta(1, "João Vitor", 1300);
		Conta conta_2 = new Conta(2, "Emerson Bottega", 2000);
		Conta conta_3 = new Conta(3, "João Schmidt", 1450);
		
		// Exibindo detalhes antes de operações
		System.out.println("Detalhes das contas:");
		conta_1.exibirDetahles();
		conta_2.exibirDetahles();
		conta_3.exibirDetahles();
		
		// Operações
		System.out.println("\n\nConta 1 detalhes:");
		conta_1.depositar(500);
		conta_1.exibirDetahles(); // Teste
		conta_1.sacar(120);
		conta_1.exibirDetahles(); // Teste
		
		System.out.println("\n\nConta 2 detalhes:");
		conta_2.depositar(450);
		conta_2.exibirDetahles(); // Teste
		conta_2.sacar(200);
		conta_2.exibirDetahles(); // Teste
		
		System.out.println("\n\nConta 3 detalhes:");
		conta_3.depositar(350);
		conta_3.exibirDetahles(); // Teste
		conta_3.sacar(150);
		conta_3.exibirDetahles(); // Teste
		
		// Exibindo detalhes após operações
		System.out.println("\n\nDetalhes das contas:");
		conta_1.exibirDetahles();
		conta_2.exibirDetahles();
		conta_3.exibirDetahles();
	}
}